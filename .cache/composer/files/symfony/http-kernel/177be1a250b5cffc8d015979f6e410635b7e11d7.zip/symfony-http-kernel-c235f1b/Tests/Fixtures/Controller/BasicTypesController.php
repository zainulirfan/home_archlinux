<?php

namespace Symfony\Component\HttpKernel\Tests\Fixtures\Controller;

class BasicTypesController
{
    public function action(string $foo, int $bar, float $baz)
    {
    }
}
